package com.devicelink.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.devicelink.app.ui.AddDeviceScreen
import com.devicelink.app.ui.ChatScreen
import com.devicelink.app.ui.DeviceListScreen
import com.devicelink.app.ui.theme.DeviceLinkTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels { MainViewModel.factory(application) }

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* opcional: só melhora notificações do serviço */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNotificationPermissionIfNeeded()

        setContent {
            DeviceLinkTheme {
                val navController = rememberNavController()
                AppNavHost(navController, viewModel)
            }
        }
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
private fun AppNavHost(navController: NavHostController, viewModel: MainViewModel) {
    NavHost(navController = navController, startDestination = "devices") {
        composable("devices") {
            DeviceListScreen(
                viewModel = viewModel,
                onOpenChat = { deviceId -> navController.navigate("chat/$deviceId") },
                onAddDevice = { navController.navigate("add") }
            )
        }
        composable("add") {
            AddDeviceScreen(
                onSave = { name, host, port ->
                    viewModel.addDevice(name, host, port)
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = "chat/{deviceId}",
            arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
        ) { backStackEntry ->
            val deviceId = backStackEntry.arguments?.getString("deviceId") ?: return@composable
            ChatScreen(
                deviceId = deviceId,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
