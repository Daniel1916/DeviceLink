package com.devicelink.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
    @TypeConverter
    fun fromDirection(value: MsgDirection): String = value.name
    @TypeConverter
    fun toDirection(value: String): MsgDirection = MsgDirection.valueOf(value)

    @TypeConverter
    fun fromType(value: MsgType): String = value.name
    @TypeConverter
    fun toType(value: String): MsgType = MsgType.valueOf(value)

    @TypeConverter
    fun fromStatus(value: MsgStatus): String = value.name
    @TypeConverter
    fun toStatus(value: String): MsgStatus = MsgStatus.valueOf(value)
}

@Database(entities = [Device::class, Message::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deviceDao(): DeviceDao
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "devicelink.db"
                ).build().also { INSTANCE = it }
            }
    }
}
