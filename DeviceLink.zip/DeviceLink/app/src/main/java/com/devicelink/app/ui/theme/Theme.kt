package com.devicelink.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = DeepTeal,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = TealContainer,
    onPrimaryContainer = DeepTealDark,
    secondary = Amber,
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = AmberContainer,
    background = BackgroundLight,
    surface = SurfaceLight,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = FailedRed
)

@Composable
fun DeviceLinkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = AppTypography,
        content = content
    )
}
