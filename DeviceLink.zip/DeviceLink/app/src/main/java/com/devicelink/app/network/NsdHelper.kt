package com.devicelink.app.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class DiscoveredPeer(val name: String, val host: String, val port: Int)

/**
 * Anuncia este aparelho na rede local via NSD (mDNS) e descobre outros aparelhos DeviceLink
 * na mesma rede Wi-Fi. Só funciona dentro do mesmo domínio de broadcast — para dispositivos
 * em outra rede (incluindo a maioria das VPNs ponto a ponto como Tailscale), adicione
 * manualmente pelo IP na tela "Adicionar dispositivo".
 */
class NsdHelper(private val context: Context) {

    private val nsdManager by lazy { context.getSystemService(Context.NSD_SERVICE) as NsdManager }
    private var registrationListener: NsdManager.RegistrationListener? = null

    fun advertise(deviceName: String, port: Int) {
        if (registrationListener != null) return
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = NSD_SERVICE_NAME_PREFIX + deviceName
            serviceType = NSD_SERVICE_TYPE
            setPort(port)
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {}
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }
        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
            registrationListener = listener
        } catch (e: Exception) {
            Log.w("NsdHelper", "Falha ao anunciar serviço na rede local", e)
        }
    }

    fun stopAdvertise() {
        registrationListener?.let {
            try {
                nsdManager.unregisterService(it)
            } catch (_: Exception) {
            }
        }
        registrationListener = null
    }

    /** Emite a lista de dispositivos DeviceLink encontrados na rede local, atualizada continuamente. */
    fun discoverPeers(): Flow<List<DiscoveredPeer>> = callbackFlow {
        val found = mutableMapOf<String, DiscoveredPeer>()
        val baseType = NSD_SERVICE_TYPE.removeSuffix(".")

        val discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}

            override fun onServiceFound(info: NsdServiceInfo) {
                if (info.serviceType != NSD_SERVICE_TYPE && !info.serviceType.startsWith(baseType)) return
                // Cada resolveService precisa de um listener novo; reaproveitar dá erro de "já em uso".
                val resolveListener = object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {}
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        val host = info.host?.hostAddress ?: return
                        val name = info.serviceName.removePrefix(NSD_SERVICE_NAME_PREFIX)
                        found[info.serviceName] = DiscoveredPeer(name, host, info.port)
                        trySend(found.values.toList())
                    }
                }
                try {
                    nsdManager.resolveService(info, resolveListener)
                } catch (_: Exception) {
                }
            }

            override fun onServiceLost(info: NsdServiceInfo) {
                found.remove(info.serviceName)
                trySend(found.values.toList())
            }
        }

        try {
            nsdManager.discoverServices(NSD_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            close(e)
        }

        awaitClose {
            try {
                nsdManager.stopServiceDiscovery(discoveryListener)
            } catch (_: Exception) {
            }
        }
    }
}
