package com.devicelink.app.network

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.devicelink.app.R
import com.devicelink.app.data.Device
import com.devicelink.app.data.Message
import com.devicelink.app.data.MsgDirection
import com.devicelink.app.data.MsgStatus
import com.devicelink.app.data.MsgType
import com.devicelink.app.data.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket

/**
 * Serviço em primeiro plano que mantém um ServerSocket TCP aberto na porta [DEFAULT_PORT],
 * pronto para receber mensagens e arquivos de qualquer dispositivo que consiga alcançar
 * este aparelho por IP — seja na mesma rede Wi-Fi ou através de uma VPN (Tailscale/WireGuard).
 */
class ConnectionService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var repository: Repository
    private var serverSocket: ServerSocket? = null

    override fun onCreate() {
        super.onCreate()
        repository = Repository(applicationContext)
        startForegroundWithNotification()
        startServer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try {
            serverSocket?.close()
        } catch (_: IOException) {
        }
        scope.cancel()
    }

    private fun startServer() {
        scope.launch {
            try {
                val server = ServerSocket(DEFAULT_PORT)
                serverSocket = server
                while (isActive) {
                    val socket = try {
                        server.accept()
                    } catch (e: IOException) {
                        break
                    }
                    launch { handleConnection(socket) }
                }
            } catch (e: IOException) {
                // Porta ocupada ou rede indisponível no momento. A notificação em primeiro
                // plano continua ativa; reabrir o app tenta novamente.
            }
        }
    }

    private suspend fun handleConnection(socket: Socket) {
        socket.use { s ->
            val remoteHost = s.inetAddress?.hostAddress ?: return
            val input = s.getInputStream()
            while (true) {
                val msg = Protocol.readMessage(input) ?: break
                when (msg) {
                    is WireMessage.Text -> handleIncomingText(remoteHost, msg)
                    is WireMessage.FileMeta -> handleIncomingFile(remoteHost, msg, input)
                }
            }
        }
    }

    private suspend fun handleIncomingText(remoteHost: String, msg: WireMessage.Text) {
        val device = resolveDevice(remoteHost, msg.fromName)
        repository.saveMessage(
            Message(
                id = msg.id,
                deviceId = device.id,
                direction = MsgDirection.IN,
                type = MsgType.TEXT,
                body = msg.body,
                timestamp = msg.timestamp,
                status = MsgStatus.RECEIVED
            )
        )
        touchLastSeen(device)
    }

    private suspend fun handleIncomingFile(remoteHost: String, meta: WireMessage.FileMeta, input: InputStream) {
        val device = resolveDevice(remoteHost, meta.fromName)
        val dir = File(applicationContext.getExternalFilesDir(null), "received").apply { mkdirs() }
        val outFile = File(dir, uniqueFileName(dir, meta.fileName))

        FileOutputStream(outFile).use { fos ->
            val buffer = ByteArray(8192)
            var remaining = meta.size
            while (remaining > 0) {
                val toRead = minOf(buffer.size.toLong(), remaining).toInt()
                val read = input.read(buffer, 0, toRead)
                if (read == -1) break
                fos.write(buffer, 0, read)
                remaining -= read
            }
        }

        repository.saveMessage(
            Message(
                id = meta.id,
                deviceId = device.id,
                direction = MsgDirection.IN,
                type = MsgType.FILE,
                fileName = meta.fileName,
                filePath = outFile.absolutePath,
                fileSize = meta.size,
                mime = meta.mime,
                timestamp = meta.timestamp,
                status = MsgStatus.RECEIVED
            )
        )
        touchLastSeen(device)
    }

    private suspend fun resolveDevice(host: String, name: String): Device {
        repository.findDeviceByHost(host)?.let { return it }
        val newDevice = Device(
            name = name,
            host = host,
            port = DEFAULT_PORT,
            addedVia = "LAN",
            lastSeen = System.currentTimeMillis()
        )
        repository.saveDevice(newDevice)
        return newDevice
    }

    private suspend fun touchLastSeen(device: Device) {
        repository.saveDevice(device.copy(lastSeen = System.currentTimeMillis()))
    }

    private fun uniqueFileName(dir: File, desired: String): String {
        var candidate = desired
        var i = 1
        while (File(dir, candidate).exists()) {
            val dot = desired.lastIndexOf('.')
            candidate = if (dot >= 0) {
                "${desired.substring(0, dot)}($i)${desired.substring(dot)}"
            } else {
                "$desired($i)"
            }
            i++
        }
        return candidate
    }

    private fun startForegroundWithNotification() {
        val channelId = "devicelink_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = getString(R.string.notification_channel_desc) }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, ConnectionService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
