package com.devicelink.app.data

import android.content.Context
import android.os.Build
import kotlinx.coroutines.flow.Flow

class Repository(context: Context) {
    private val db = AppDatabase.get(context)
    private val prefs = context.getSharedPreferences("devicelink_prefs", Context.MODE_PRIVATE)

    val deviceDao get() = db.deviceDao()
    val messageDao get() = db.messageDao()

    fun observeDevices(): Flow<List<Device>> = deviceDao.observeAll()
    fun observeMessages(deviceId: String): Flow<List<Message>> = messageDao.observeForDevice(deviceId)

    suspend fun saveDevice(device: Device) = deviceDao.insert(device)
    suspend fun removeDevice(device: Device) = deviceDao.delete(device)
    suspend fun findDeviceByHost(host: String): Device? = deviceDao.getByHost(host)
    suspend fun findDeviceById(id: String): Device? = deviceDao.getById(id)

    suspend fun saveMessage(message: Message) = messageDao.insert(message)
    suspend fun updateMessage(message: Message) = messageDao.update(message)
    suspend fun findMessage(id: String): Message? = messageDao.getById(id)

    /** Nome que este aparelho mostra para os outros (editável pelo usuário). */
    var myDeviceName: String
        get() = prefs.getString("my_name", null) ?: defaultDeviceName()
        set(value) = prefs.edit().putString("my_name", value).apply()

    private fun defaultDeviceName(): String =
        Build.MODEL?.takeIf { it.isNotBlank() } ?: "Meu aparelho"
}
