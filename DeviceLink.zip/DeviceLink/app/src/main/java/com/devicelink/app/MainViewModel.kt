package com.devicelink.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.devicelink.app.data.Device
import com.devicelink.app.data.Message
import com.devicelink.app.data.MsgDirection
import com.devicelink.app.data.MsgStatus
import com.devicelink.app.data.MsgType
import com.devicelink.app.network.DEFAULT_PORT
import com.devicelink.app.network.DiscoveredPeer
import com.devicelink.app.network.NsdHelper
import com.devicelink.app.network.PeerClient
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as DeviceLinkApplication).repository
    private val nsdHelper = NsdHelper(application)

    val devices: StateFlow<List<Device>> = repo.observeDevices()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val discoveredPeers: StateFlow<List<DiscoveredPeer>> = nsdHelper.discoverPeers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var myName: String
        get() = repo.myDeviceName
        set(value) {
            repo.myDeviceName = value
        }

    init {
        nsdHelper.advertise(myName, DEFAULT_PORT)
    }

    override fun onCleared() {
        super.onCleared()
        nsdHelper.stopAdvertise()
    }

    fun messagesFor(deviceId: String): StateFlow<List<Message>> =
        repo.observeMessages(deviceId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addDevice(name: String, host: String, port: Int) {
        viewModelScope.launch {
            repo.saveDevice(Device(name = name, host = host, port = port, addedVia = "MANUAL"))
        }
    }

    fun addDiscovered(peer: DiscoveredPeer) {
        viewModelScope.launch {
            repo.saveDevice(Device(name = peer.name, host = peer.host, port = peer.port, addedVia = "LAN"))
        }
    }

    fun removeDevice(device: Device) {
        viewModelScope.launch { repo.removeDevice(device) }
    }

    fun sendText(device: Device, text: String) {
        val id = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()
        viewModelScope.launch {
            repo.saveMessage(
                Message(
                    id = id,
                    deviceId = device.id,
                    direction = MsgDirection.OUT,
                    type = MsgType.TEXT,
                    body = text,
                    timestamp = timestamp,
                    status = MsgStatus.SENDING
                )
            )
            val result = PeerClient.sendText(device.host, device.port, myName, id, text, timestamp)
            updateStatus(id, result.isSuccess)
        }
    }

    fun sendFile(device: Device, uri: Uri) {
        val id = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()
        val context = getApplication<Application>()
        val info = PeerClient.resolveFileInfo(context, uri)
        viewModelScope.launch {
            repo.saveMessage(
                Message(
                    id = id,
                    deviceId = device.id,
                    direction = MsgDirection.OUT,
                    type = MsgType.FILE,
                    fileName = info?.name ?: "arquivo",
                    fileSize = info?.size,
                    mime = info?.mime,
                    timestamp = timestamp,
                    status = MsgStatus.SENDING
                )
            )
            val result = PeerClient.sendFile(context, device.host, device.port, myName, id, uri, timestamp)
            updateStatus(id, result.isSuccess)
        }
    }

    /** Reenvia uma mensagem de texto que falhou. */
    fun retryText(message: Message, device: Device) {
        if (message.type != MsgType.TEXT || message.body == null) return
        viewModelScope.launch {
            repo.updateMessage(message.copy(status = MsgStatus.SENDING))
            val result = PeerClient.sendText(device.host, device.port, myName, message.id, message.body, message.timestamp)
            updateStatus(message.id, result.isSuccess)
        }
    }

    private suspend fun updateStatus(id: String, success: Boolean) {
        val current = repo.findMessage(id) ?: return
        repo.updateMessage(current.copy(status = if (success) MsgStatus.SENT else MsgStatus.FAILED))
    }

    companion object {
        fun factory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    MainViewModel(application) as T
            }
    }
}
