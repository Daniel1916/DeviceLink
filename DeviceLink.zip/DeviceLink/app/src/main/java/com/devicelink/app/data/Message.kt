package com.devicelink.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class MsgDirection { IN, OUT }
enum class MsgType { TEXT, FILE }
enum class MsgStatus { SENDING, SENT, RECEIVED, FAILED }

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val deviceId: String,
    val direction: MsgDirection,
    val type: MsgType,
    val body: String? = null,       // texto da mensagem, quando type = TEXT
    val fileName: String? = null,   // nome do arquivo, quando type = FILE
    val filePath: String? = null,   // caminho local do arquivo (enviado ou recebido)
    val fileSize: Long? = null,
    val mime: String? = null,
    val timestamp: Long,
    val status: MsgStatus
)
