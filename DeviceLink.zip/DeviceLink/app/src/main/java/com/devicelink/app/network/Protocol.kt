package com.devicelink.app.network

import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets

/** Porta TCP usada pelo DeviceLink em todos os aparelhos. */
const val DEFAULT_PORT = 58217

/** Usados para descoberta automática na rede local (NSD/mDNS). */
const val NSD_SERVICE_TYPE = "_devicelink._tcp."
const val NSD_SERVICE_NAME_PREFIX = "DeviceLink-"

private const val MAX_HEADER_BYTES = 1_000_000 // 1 MB é mais que suficiente para um cabeçalho JSON

sealed class WireMessage {
    data class Text(
        val id: String,
        val fromName: String,
        val body: String,
        val timestamp: Long
    ) : WireMessage()

    /** Cabeçalho de um arquivo. Os bytes do arquivo (tamanho [size]) vêm logo em seguida no stream. */
    data class FileMeta(
        val id: String,
        val fromName: String,
        val fileName: String,
        val size: Long,
        val mime: String,
        val timestamp: Long
    ) : WireMessage()
}

/**
 * Protocolo simples: cada frame é [tamanho em 4 bytes big-endian][JSON em UTF-8].
 * Para arquivos, logo após o frame do tipo "file" seguem exatamente [FileMeta.size] bytes crus.
 */
object Protocol {

    fun writeText(out: OutputStream, id: String, fromName: String, body: String, timestamp: Long) {
        val json = JSONObject()
            .put("type", "text")
            .put("id", id)
            .put("from", fromName)
            .put("body", body)
            .put("ts", timestamp)
        writeFrame(out, json)
    }

    fun writeFileMeta(
        out: OutputStream,
        id: String,
        fromName: String,
        fileName: String,
        size: Long,
        mime: String,
        timestamp: Long
    ) {
        val json = JSONObject()
            .put("type", "file")
            .put("id", id)
            .put("from", fromName)
            .put("name", fileName)
            .put("size", size)
            .put("mime", mime)
            .put("ts", timestamp)
        writeFrame(out, json)
    }

    private fun writeFrame(out: OutputStream, json: JSONObject) {
        val bytes = json.toString().toByteArray(StandardCharsets.UTF_8)
        val dos = DataOutputStream(out)
        dos.writeInt(bytes.size)
        dos.write(bytes)
        dos.flush()
    }

    /** Lê o próximo frame de controle do stream. Retorna null se a conexão fechou. */
    fun readMessage(input: InputStream): WireMessage? {
        val dis = DataInputStream(input)
        val len = try {
            dis.readInt()
        } catch (e: java.io.EOFException) {
            return null
        }
        if (len <= 0 || len > MAX_HEADER_BYTES) return null
        val buf = ByteArray(len)
        dis.readFully(buf)
        val json = JSONObject(String(buf, StandardCharsets.UTF_8))
        return when (json.optString("type")) {
            "text" -> WireMessage.Text(
                id = json.getString("id"),
                fromName = json.getString("from"),
                body = json.getString("body"),
                timestamp = json.getLong("ts")
            )
            "file" -> WireMessage.FileMeta(
                id = json.getString("id"),
                fromName = json.getString("from"),
                fileName = json.getString("name"),
                size = json.getLong("size"),
                mime = json.optString("mime", "application/octet-stream"),
                timestamp = json.getLong("ts")
            )
            else -> null
        }
    }
}
