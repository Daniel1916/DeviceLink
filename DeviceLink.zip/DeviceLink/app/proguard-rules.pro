# Regras padrão do ProGuard/R8. Ajuste conforme necessário se ativar minify no release.
